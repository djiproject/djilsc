detect.tflite: model file
labelmap: label file
